Live2D SDK follows live2d license. Check Live2D-Demo/Assets/Live2D/Cubism/license.txt.

Texture file follows CC BY-NC-SA license.
