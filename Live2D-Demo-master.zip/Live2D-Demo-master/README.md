# Live2D Demo
Cubism 3 SDK for Unity Demo.

Texture file is not permitted for commercial purposes.

If Unity Editor prints DLLNotFoundException: Live2DCubismCore.dll, Follow these steps:

1. Copy "Live2DCubismCore.dll", which locates at "Assets\Live2D\Cubism\Plugins\Windows\x86_64 or x86"
2. Paste the dll file in Unity Editor folder. (Ex. C:\Program Files\Unity\Editor)
