# Cubism 3.0 SDK Core Native Plugin

This folder contains the Cubism SDK native plugin(s).
*If you encounter exceptions upon first import, restart Unity*.
